<picture>
  <img src="https://raw.githubusercontent.com/waktool/.github/main/assets/PS99_Ranks.webp">
</picture>

<a name="title"><h1># Rank Quests</h1></a>
A macro that ranks you up automatically.
- <a href="https://github.com/waktool/RankQuests/releases">Releases</a>
- <a href="https://github.com/waktool/RankQuests/wiki">Wiki</a>
- <a href="https://github.com/waktool/RankQuests/issues">Issues & Suggestions</a>
